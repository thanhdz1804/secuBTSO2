from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.serialization import pkcs12
from endesive.pdf import cms
import datetime

def sign_pdf():
    # Đọc file .pfx cá nhân
    with open("thannhanthanh.pfx", "rb") as f:
        pfx_data = f.read()

    private_key, cert, add_certs = pkcs12.load_key_and_certificates(
        pfx_data, b"123456"
    )

    # Chuẩn bị thông tin chữ ký
    date = datetime.datetime.utcnow().strftime("D:%Y%m%d%H%M%S+00'00'")
    signature = {
    "sigflags": 3,
    "contact": "Thân Nhân Thành",
    "location": "Thai Nguyen University of Technology",
    "signingdate": date,
    "reason": "Bài tập chữ ký số - An toàn và bảo mật thông tin",
    "signature": "Thân Nhân Thành",
    "signature_img": "signature.png",

    # 🔹 Thêm hiển thị hình chữ ký trong trang PDF
    "sigpage": 0,                # Trang đầu tiên
    "sigbutton": True,           # Hiển thị khung vùng chữ ký
    "sigfield": "Signature1",    # Tên trường chữ ký
    "box": (380, 70, 570, 210),  # (x1, y1, x2, y2): điều chỉnh vị trí góc phải-dưới
    "text": (
        "Người ký: Thân Nhân Thành\n"
        "Ngày ký: 30/10/2025\n"
        "Trường ĐH Kỹ thuật Công nghiệp - TNUT"
    ),
}



    # Đọc file PDF gốc
    with open("original.pdf", "rb") as f:
        datau = f.read()

    # Ký PDF bằng SHA256 + RSA
    datas = cms.sign(datau, signature, private_key, cert, add_certs, "sha256")

    # Ghi ra file PDF đã ký
    with open("signed.pdf", "wb") as f:
        f.write(datau + datas)

    print("✅ Đã tạo file signed.pdf có chữ ký số hợp lệ!")

if __name__ == "__main__":
    sign_pdf()
